package com.examples.crud.fisemployeecrud;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FisemployeecrudApplicationTests {

	@Test
	void contextLoads() {
	}

}
