package fisglobal;

public class Address {
	int dno;
	String street;
	String city;
	Address(int dno, String street, String city){
		this.dno=dno;
		this.street=street;
		this.city=city;
	}

}
