package fisglobal;

public class HelloWorld {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a=10,b=20;
		String name="Kumar";
		System.out.println("Hello World...!");
		System.out.println(a);
		System.out.println(b);
		System.out.println(name);
		System.out.println("The first number: "+a);
		

	}

}
