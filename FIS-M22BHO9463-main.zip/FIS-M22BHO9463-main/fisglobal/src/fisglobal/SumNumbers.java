package fisglobal;

import java.util.Scanner;

public class SumNumbers {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int a, b, c;
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first number");
		a=sc.nextInt();
		System.out.println("Enter the Second number");
		b=sc.nextInt();
		c=a+b;
		System.out.println("The sum is :"+c);


	}

}
