package fisglobal;

public class TestStudent {

	
	public static void main(String[] args) {
		
		//Student s1 = new Student("praveen");
		
		
	//	Student s2 = new Student("Kumar","EEE");
		
		
		Student s3 = new Student();
	
		
		// this()  ;;
	}	

}
