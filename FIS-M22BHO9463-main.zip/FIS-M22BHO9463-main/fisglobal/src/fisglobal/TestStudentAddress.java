package fisglobal;

public class TestStudentAddress {

}
