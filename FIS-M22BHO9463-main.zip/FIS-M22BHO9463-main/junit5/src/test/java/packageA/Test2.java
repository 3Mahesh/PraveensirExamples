package packageA;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;

public class Test2 {
	void test4() {
		System.out.println("Package A -Inside test5");
	}
	@Test
	void test5() {
		System.out.println("Package A - Inside test5");
	}
	@Test
	
	void test6() {
		System.out.println("Package A - Inside test6");
	}
	
}
