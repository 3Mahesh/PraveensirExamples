package projectaop;

public class TestCustomer {
	
	protected void test1() {
		System.out.println("Test1 is called...");
	}
	
	public void test2() {
		System.out.println("Test2 is called...");
	}

}
