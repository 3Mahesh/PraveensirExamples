package com.example.service22.service22;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Service22ApplicationTests {

	@Test
	void contextLoads() {
	}

}
