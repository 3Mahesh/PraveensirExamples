package examples2;

public interface UserService {
	
	public String getServiceType();
}
