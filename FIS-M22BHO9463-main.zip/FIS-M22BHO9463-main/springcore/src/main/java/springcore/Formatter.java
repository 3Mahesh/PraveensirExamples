package springcore;

public interface Formatter {
	public String format();

}
