package springcore;

import org.springframework.stereotype.Component;

@Component
public interface GeoMetry {
	
	public String getShape();

}
