package springcore;

public class Rectangle {

	public String getShape() {
		// TODO Auto-generated method stub
		return "Shape of Object is Rectangle";
	}

}
